
/**
 * motorcycle
 * @version 1.0
 * @since today
 * @author darshit
 * */public class Motorcycle extends sells{
    /**
 
     * @param topSpeed topSpeed 
     */
    public Motorcycle(int topSpeed) {
        super(topSpeed);
    }

    /**
 
     * @param y bike prices 
     * @return
     */
    public static int currentBikePrice(double y){
        int x;
        x= (int) (y% Cost);

        return x;
    }
}
/**
     *
     *this is darshit's code 
     */