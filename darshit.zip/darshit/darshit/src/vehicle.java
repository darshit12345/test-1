import java.sql.Date;

/**
 * vehicle
 * @version 1.0
 * @since today
 * @author darshit
 * */
public class vehicle extends sells{
    private int registrationNum;
    public int isregistrationNum() {
        return registrationNum;
    }

    private int price;
    private Date yearOfPurchase;

    /**

     * @param model vehicle model
     * @param registrationNum number of registaration
     * @param price vehicle price 
     * @param yearOfPurchase purchase of the year  
     */

    public vehicle(String model, int registrationNum , int price, date yearOfPurchase) {
        super(model,100);
        this.yearOfPurchase = yearOfPurchase;
        this.price = price;
        this.registrationNum = registrationNum;
    }

    public void set(date yearOfPurchase) {
        this.yearOfPurchase = yearOfPurchase;
    }

    public int isregistrationNum() {
        return registrationNum;
    }

    public void setregistrationNum(int registrationNum) {
        this.registrationNum = registrationNum;
    }

    public int isprice() {
        return price;
    }

    public void setprice(boolean price) {
        this.price = price;
    }

    /**
     *
     * @param x must be spend this amount 
     * @return
     */
    public static int howManyvehicles(double x){
        int y;
        y= (int) (x%Cost);

        return y;
    }
}

/**
     *
     *this is darshit's code 
     */