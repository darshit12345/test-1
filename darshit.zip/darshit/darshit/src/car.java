import java.util.ArrayList;
/**
 * user
 * @version 1.0
 * @since today
 * @author darshit
 * */

 

public class car extends sells{
    private int numOfPassengers;
 
    ArrayList<Pesengers> pesengerslist=new ArrayList<>();

    /**
  
     * @param numOfPassengers number of passengers 
  
     */
    public car(int numOfPassengers) {
        this.numOfPassengers = numOfPassengers;
   

    }

    public int getnumOfPassengers() {
        return numOfPassengers;
    }

    public void setnumOfPassengers(int numOfPassengers) {
        this.numOfPassengers = numOfPassengers;
    }



    /**

     * @param p pasenger need 
     * @return
     */
    public String currentCarPrice(showroom x){
        if(this.inventory<x.space){
            return "Inventory overflow";
        }else{
            spots.add(x);
            inventory=-x.spots;
            if(spots<2){
                return "Low inventory";
            }
            return "Inventory updated";
        }
    }

    /**
     * @return Number of vehicle
     */
    public int displayvehicle(){
        for(showroom p:Inventorylist){
            System.out.println(p.getvehicle());
        }
        return Inventorylist.price();
    }
}

/**
     *
     *this is darshit's code 
     */