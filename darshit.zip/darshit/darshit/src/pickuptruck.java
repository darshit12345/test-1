/**
 * Coffee
 * @version 1.0
 * @since today
 * @author darshit
 * */
public class PickupTrucks extends sells{
    private int loadCapacity;
   

    /**

     * @param 	loadCapacity capicity of trucks 
    
     */

    public PickupTrucks(int loadCapacity ) {

        super(loadCapacity);
        this.loadCapacity=	loadCapacity;
     
    }


    public int getloadCapacity() {
        return loadCapacity;
    }

    public void setloadCapacity(int loadCapacity) {
        this.loadCapacity = loadCapacity;
    }

  

    /**
    
     * @param z current truck price
     * @return
     */
    public static int currentTruckPrice(double x){
        int z;
        z= (int) (x%Cost);

        return z;
    }
}

/**
     *
     *this is darshit's code 
     */