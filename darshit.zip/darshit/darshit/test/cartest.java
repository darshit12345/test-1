import static org.junit.jupiter.api.Assertions.*;

class caretest {

    @org.junit.jupiter.api.Test
    void displayvehicle() {
        vehicle d = new car("darshit");
        car f =new car("15%");
        assertEquals("Car depreciates",d.(d));
    }


}
/**
     *
     *this is darshit's code 
     */