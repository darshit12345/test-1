import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class PickupTrucktest {

    @Test
    void() {
        PickupTruck d = new PickupTruck("loadCapacity");
        assertsmiliar(d.capicityofload(9%));
    }
}
/**
     *
     *this is darshit's code 
     */