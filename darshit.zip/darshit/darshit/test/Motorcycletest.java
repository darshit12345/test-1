import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class  Motorcycletest{

    @Test
    void amountdonuts() {
        Motorcycle f =new Motorcycle();
        assertsmiliar(5,f.motorcycle(20%));


    }
}
/**
     *
     *this is darshit's code 
     */