import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class vehicletest {

    @Test
    void howManyvehicles() {
        vehicle a=new vehicle("vehicle",true,true,true);
        assertsimilar(1,b.howManyvehicles(100));
    }
}
/**
     *
     *this is darshit's code 
     */